/**
 * Vercel serverless function: proxies chat requests to AI providers.
 * Streams SSE events back to the client.
 *
 * Request body:
 * {
 *   config: { name, baseUrl, apiKey, cascade, thinkingMode, maxTokens },
 *   messages: [{ role, text, attachments? }],
 *   settings: { stream, maxTokens, thinkingMode },
 *   webSearch: boolean,
 *   tavilyKey: string
 * }
 *
 * Response: text/event-stream with { type, ... } events.
 */
export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  // Disable buffering for streaming
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('X-Accel-Buffering', 'no');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const { config, messages, settings } = req.body || {};

  if (!config || !messages || !Array.isArray(messages)) {
    res.write('data: ' + JSON.stringify({ type: 'error', error: 'Invalid request body.' }) + '\n\n');
    res.end();
    return;
  }

  const { createProxyStream } = await import('./_stream');

  const baseUrl = config.baseUrl || '';
  const provider = detectProvider(baseUrl);

  // Build an AbortController for this request
  const abortController = new AbortController();
  let aborted = false;

  // Detect client disconnect (browser abort)
  const onClose = () => {
    if (!res.writableEnded && !aborted) {
      aborted = true;
      abortController.abort();
    }
  };
  res.on('close', onClose);
  res.on('error', onClose);

  const write = (payload: any) => {
    if (!aborted && !res.writableEnded) {
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    }
  };

  const end = () => {
    if (!aborted && !res.writableEnded) {
      res.end();
    }
    res.removeListener('close', onClose);
    res.removeListener('error', onClose);
  };

  try {
    await createProxyStream({
      provider,
      config,
      messages,
      settings,
      signal: abortController.signal,
      write,
    });
    if (!aborted) {
      write({ type: 'done', modelUsed: config.cascade?.[0] || 'unknown' });
    }
  } catch (err: any) {
    if (!aborted) {
      write({ type: 'error', error: err.message || 'Provider request failed.' });
    }
  } finally {
    end();
  }
}

function detectProvider(baseUrl: string): 'gemini' | 'groq' | 'openrouter' | 'nvidia' | 'zai' | 'custom' {
  const b = baseUrl.toLowerCase();
  if (b.includes('generativelanguage.googleapis.com')) return 'gemini';
  if (b.includes('api.groq.com')) return 'groq';
  if (b.includes('openrouter.ai')) return 'openrouter';
  if (b.includes('integrate.api.nvidia.com')) return 'nvidia';
  if (b.includes('api.z.ai')) return 'zai';
  return 'custom';
}
