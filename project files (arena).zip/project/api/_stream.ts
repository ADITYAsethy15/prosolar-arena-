import type { ProviderConfig } from '../src/types';

export interface ProxyStreamContext {
  provider: 'gemini' | 'groq' | 'openrouter' | 'nvidia' | 'zai' | 'custom';
  config: ProviderConfig & { baseUrl: string; apiKey: string };
  messages: any[];
  settings: { stream: boolean; maxTokens: number; thinkingMode: string };
  signal: AbortSignal;
  write: (payload: any) => void;
}

const STREAM_TIMEOUT_MS = 240_000; // 4 minutes

export async function createProxyStream(ctx: ProxyStreamContext): Promise<void> {
  const { provider, config, messages, settings, signal, write } = ctx;

  const model = config.cascade?.[0] || 'default';
  const apiKey = config.apiKey;
  const baseUrl = config.baseUrl;

  /* ---------- Gemini (native SDK REST) ---------- */
  if (provider === 'gemini') {
    write({ type: 'model_init', model });
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?key=${apiKey}`;
    const body = {
      contents: messages.map((m: any) => ({
        role: m.role === 'model' ? 'model' : 'user',
        parts: [{ text: m.text }],
      })),
      generationConfig: {
        maxOutputTokens: config.maxTokens || settings.maxTokens,
        temperature: 0.7,
      },
    };

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal,
    });

    if (!res.ok || !res.body) {
      const errText = await res.text().catch(() => '');
      throw new Error(`Gemini API error (${res.status}): ${errText}`);
    }

    await processSseStream(res.body!, signal, write);
    return;
  }

  /* ---------- OpenAI-compatible (Groq, OpenRouter, NVIDIA, Z.AI, Custom) ---------- */
  const chatUrl = `${baseUrl.replace(/\/+$/, '')}/chat/completions`;
  const payload: any = {
    model,
    messages: messages.map((m: any) => ({ role: m.role === 'model' ? 'assistant' : 'user', content: m.text })),
    stream: true,
    ...(provider === 'groq' ? { max_completion_tokens: config.maxTokens || settings.maxTokens } : { max_tokens: config.maxTokens || settings.maxTokens }),
    temperature: 0.7,
  };

  write({ type: 'model_init', model });

  const res = await fetch(chatUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(payload),
    signal,
  });

  if (!res.ok || !res.body) {
    const errText = await res.text().catch(() => '');
    throw new Error(`${provider} API error (${res.status}): ${errText}`);
  }

  await processSseStream(res.body!, signal, write);
}

async function processSseStream(
  stream: ReadableStream<Uint8Array>,
  signal: AbortSignal,
  write: (payload: any) => void
): Promise<void> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  const deadline = AbortSignal.timeout(STREAM_TIMEOUT_MS);
  const combinedSignal = AbortSignal.any([signal, deadline]);

  try {
    while (true) {
      if (combinedSignal.aborted) throw new Error('Request aborted or timed out.');
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (combinedSignal.aborted) throw new Error('Request aborted.');
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith(':')) continue;
        if (trimmed === 'data: [DONE]') continue;
        if (trimmed.startsWith('data: ')) {
          const jsonStr = trimmed.slice(6).trim();
          if (!jsonStr) continue;
          try {
            const event = JSON.parse(jsonStr);
            write(event);
          } catch {
            // ignore malformed SSE lines
          }
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
}
