import React, { useMemo } from 'react';
import { marked } from 'marked';
import katex from 'katex';
import 'katex/dist/contrib/mhchem';

export interface MarkdownRendererProps {
  content: string;
}

interface MathItem {
  token: string;
  math: string;
  isBlock: boolean;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

const KNOWN_LATEX_COMMANDS = new Set([
  'frac','dfrac','cfrac','sqrt','text','textbf','textit','textrm','mathrm','mathbf','mathit','mathcal','mathbb',
  'ce','pu','times','cdot','div','pm','mp','leq','geq','le','ge','neq','approx','sim','simeq','infty',
  'propto','sum','prod','int','iint','iiint','oint','lim','inf','sup','min','max','sin','cos','tan',
  'cot','sec','csc','sinh','cosh','tanh','log','ln','exp','det','dim','ker','deg','partial','nabla',
  'd','dx','dy','dt','alpha','beta','gamma','delta','epsilon','varepsilon','zeta','eta','theta','vartheta',
  'iota','kappa','lambda','mu','nu','xi','pi','varpi','rho','varrho','sigma','varsigma','tau','upsilon',
  'phi','varphi','chi','psi','omega','Gamma','Delta','Theta','Lambda','Xi','Pi','Sigma','Upsilon','Phi','Psi','Omega',
  'left','right','big','Big','bigg','Bigg','begin','end','overline','underline','hat','check','breve','acute',
  'grave','tilde','bar','vec','dot','ddot','arrow','rightarrow','leftarrow','implies','iff','Rightarrow','Leftarrow',
  'longrightarrow','longleftarrow','to','mapsto','quad','qquad','hspace','vspace','phantom','color','over','atop',
  'degree','celcius','celsius','ohm','micro','unit','circ','angle','perp','parallel','therefore','because','bold','cancel'
]);

const KATEX_MACROS: Record<string, string> = {
  '\\pu': '\\mathrm{#1}',
  '\\d': '\\mathrm{d}',
  '\\degree': '^\\circ',
  '\\celcius': '^\\circ\\mathrm{C}',
  '\\celsius': '^\\circ\\mathrm{C}',
  '\\ohm': '\\Omega',
  '\\micro': '\\mu',
  '\\unit': '\\mathrm{#1}',
  '\\cancel': '\\not{#1}',
  '\\bold': '\\mathbf{#1}',
};

function renderMathWithHealing(rawMath: string, isBlock: boolean): string {
  const tryRender = (m: string) =>
    katex.renderToString(m, {
      displayMode: isBlock,
      throwOnError: true,
      strict: false,
      output: 'htmlAndMathml',
      trust: false,
      macros: KATEX_MACROS,
    });

  try {
    return tryRender(rawMath);
  } catch (err: any) {
    let healed = rawMath;
    const openBraces = (healed.match(/\{/g) || []).length;
    const closeBraces = (healed.match(/\}/g) || []).length;
    if (openBraces > closeBraces) healed += '}'.repeat(openBraces - closeBraces);
    else if (closeBraces > openBraces) healed = '{'.repeat(closeBraces - openBraces) + healed;

    const undefinedMatch = (err?.message || '').match(/Undefined control sequence:\s*\\([a-zA-Z]+)/);
    if (undefinedMatch) {
      const badCmd = undefinedMatch[1];
      healed = healed.replace(new RegExp('\\\\' + badCmd + '\\b', 'g'), `\\\\text{${badCmd}}`);
    }

    try {
      return tryRender(healed);
    } catch {
      try {
        const sanitized = healed.replace(/\\([a-zA-Z]+)/g, (match, cmd) =>
          KNOWN_LATEX_COMMANDS.has(cmd) ? match : `\\\\text{${cmd}}`,
        );
        return tryRender(sanitized);
      } catch {
        return `<span class="katex-fallback font-mono text-cyan-300 text-sm bg-zinc-900/70 px-1.5 py-0.5 rounded border border-zinc-800">${escapeHtml(rawMath)}</span>`;
      }
    }
  }
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const htmlContent = useMemo(() => {
    if (!content) return '';
    try {
      const mathItems: MathItem[] = [];
      let tokenCounter = 0;
      let processed = content.trim();

      // DeepSeek / thinking tags
      processed = processed.replace(/\<think\>([\s\S]*?)\<\/think\>/gi, (_, thinkContent) =>
        `\n\n<details class="deepseek-thought-process my-3 rounded-xl border border-indigo-900/60 bg-indigo-950/25 px-4 py-2.5 text-xs text-indigo-300"><summary class="cursor-pointer font-semibold text-indigo-300 hover:text-indigo-200 flex items-center gap-1.5 py-1 select-none"><span>🧠 Thought Process</span></summary><div class="mt-2 text-zinc-300 leading-relaxed whitespace-pre-wrap text-[14.5px] border-t border-indigo-900/40 pt-2.5 select-text">${thinkContent.trim()}</div></details>\n\n`
      );
      if (processed.includes('<think>')) {
        processed = processed.replace(/\<think\>([\s\S]*)$/gi, (_, thinkContent) =>
          `\n\n<details open class="deepseek-thought-process my-3 rounded-xl border border-indigo-900/60 bg-indigo-950/25 px-4 py-2.5 text-xs text-indigo-300 animate-pulse"><summary class="cursor-pointer font-semibold text-indigo-300 hover:text-indigo-200 flex items-center gap-1.5 py-1 select-none"><span>🧠 Reasoning in progress...</span></summary><div class="mt-2 text-zinc-300 leading-relaxed whitespace-pre-wrap text-[14.5px] border-t border-indigo-900/40 pt-2.5 select-text">${thinkContent.trim()}</div></details>\n\n`
        );
      }

      // Double backslash normalization
      processed = processed.replace(
        /\\\\(frac|sqrt|times|alpha|beta|gamma|delta|theta|lambda|pi|sigma|omega|text|mathbf|mathrm|ce|pu|left|right|begin|end|sum|int|lim|to|infty|approx|pm|cdot|vec|hat|bar|quad|qquad|Delta|nabla)/g,
        '\\$1',
      );

      // Extract ```math / ```latex blocks
      processed = processed.replace(/```(?:math|latex)\s*([\s\S]*?)```/gi, (_, math) => {
        const token = `KATEXMATHBLOCK${tokenCounter++}END`;
        mathItems.push({ token, math: math.trim(), isBlock: true });
        return token;
      });

      // $$...$$
      processed = processed.replace(/^[ \t]*\$\$([\s\S]*?)\$\$/gm, (_, math) => {
        const token = `KATEXMATHBLOCK${tokenCounter++}END`;
        mathItems.push({ token, math: math.trim(), isBlock: true });
        return token;
      });
      processed = processed.replace(/\$\$([\s\S]*?)\$\$/g, (_, math) => {
        const token = `KATEXMATHBLOCK${tokenCounter++}END`;
        mathItems.push({ token, math: math.trim(), isBlock: true });
        return token;
      });

      // \[...\] and \(...\)
      processed = processed.replace(/\\\[([\s\S]*?)\\\]/g, (_, math) => {
        const token = `KATEXMATHBLOCK${tokenCounter++}END`;
        mathItems.push({ token, math: math.trim(), isBlock: true });
        return token;
      });
      processed = processed.replace(/\\\(([\s\S]*?)\\\)/g, (_, math) => {
        const token = `KATEXMATHINLINE${tokenCounter++}END`;
        mathItems.push({ token, math: math.trim(), isBlock: false });
        return token;
      });

      // \ce{...}
      processed = processed.replace(/(?<![\$\\])\\ce\{([^{}]+(?:\{[^{}]*\}[^{}]*)*)\}/g, (_, chem) => {
        const token = `KATEXMATHINLINE${tokenCounter++}END`;
        mathItems.push({ token, math: `\\ce{${chem}}`, isBlock: false });
        return token;
      });

      // $...$ inline
      processed = processed.replace(/(?<!\\)\$([^\s$](?:[^\$\n\r]*?[^\s$])?)\$(?!\$)/g, (match, math) => {
        const trimmed = math.trim();
        if (!trimmed) return match;
        const token = `KATEXMATHINLINE${tokenCounter++}END`;
        mathItems.push({ token, math: trimmed, isBlock: false });
        return token;
      });

      // Auto-close unbalanced $$
      if ((processed.match(/\$\$/g) || []).length % 2 !== 0) processed += '\n$$';

      marked.setOptions({ gfm: true, breaks: true });
      let html = marked.parse(processed) as string;

      for (const item of mathItems) {
        const renderedMath = renderMathWithHealing(item.math, item.isBlock);
        if (item.isBlock) {
          const blockHtml = `<div class="katex-display-wrapper my-2.5 overflow-x-auto py-2 px-3 rounded-xl bg-zinc-900/70 border border-zinc-800 text-cyan-200">${renderedMath}</div>`;
          const pRegex = new RegExp(`<p>\\s*${item.token}\\s*</p>`, 'g');
          html = pRegex.test(html) ? html.replace(pRegex, blockHtml) : html.split(item.token).join(blockHtml);
        } else {
          const inlineHtml = `<span class="katex-inline-wrapper font-medium text-cyan-200">${renderedMath}</span>`;
          html = html.split(item.token).join(inlineHtml);
        }
      }

      return html;
    } catch (e) {
      console.error('Markdown parse error:', e);
      try { return marked.parse(content) as string; } catch { return content; }
    }
  }, [content]);

  return (
    <div className="study-prose text-zinc-200 leading-relaxed break-words" dangerouslySetInnerHTML={{ __html: htmlContent }} />
  );
};
