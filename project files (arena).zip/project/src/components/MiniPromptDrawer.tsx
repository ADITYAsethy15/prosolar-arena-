import React from 'react';

export const MINI_PROMPTS = [
  { label: 'Summarize', snippet: 'Please summarize the key points:' },
  { label: 'Explain', snippet: 'Explain this step by step:' },
  { label: 'Code', snippet: 'Write clean, commented code for:' },
  { label: 'Translate', snippet: 'Translate to English:' },
  { label: 'Critique', snippet: 'Critique this and suggest improvements:' },
];

interface MiniPromptDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertPrompt: (snippet: string) => void;
}

export const MiniPromptDrawer: React.FC<MiniPromptDrawerProps> = ({
  isOpen, onClose, onInsertPrompt,
}) => {
  if (!isOpen) return null;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-end justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in"
    >
      <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-md p-4 shadow-2xl text-zinc-100 animate-in zoom-in duration-200">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-zinc-100 text-sm">Mini Prompts</h3>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200">✕</button>
        </div>
        <p className="text-xs text-zinc-500 mb-4">Quick-insert snippets into the composer.</p>
        <div className="space-y-2">
          {MINI_PROMPTS.map((p) => (
            <button
              key={p.label}
              onClick={() => { onInsertPrompt(p.snippet); onClose(); }}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-sm transition-colors cursor-pointer"
            >
              <span>{p.label}</span>
              <span className="text-[10px] text-zinc-500 font-mono">→</span>
            </button>
          ))}
        </div>
        <div className="mt-4 pt-2 border-t border-zinc-800 text-[10px] text-zinc-500 text-center">
          No subject filtering — snippets insert directly into the textbox.
        </div>
      </div>
    </div>
  );
};
