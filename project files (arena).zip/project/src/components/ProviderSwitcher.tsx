import React from 'react';
import type { ProviderId } from '@/types';
import { CUSTOM_PROVIDER_IDS, ALL_PROVIDERS, PROVIDER_DISPLAY } from '@/types';
import { getCustomProviders, getApiKeys } from '@/lib/storage';

interface ProviderSwitcherProps {
  activeProvider: ProviderId;
  setActiveProvider: (pid: ProviderId) => void;
}

export const ProviderSwitcher: React.FC<ProviderSwitcherProps> = ({
  activeProvider, setActiveProvider,
}) => {
  const customProviders = getCustomProviders();
  const apiKeys = getApiKeys();

  return (
    <div className="flex items-center gap-1 overflow-x-auto pb-1">
      {ALL_PROVIDERS.map((pid) => {
        const info = PROVIDER_DISPLAY[pid];
        const hasKey = !!apiKeys[pid];
        const isCustom = pid === 'custom-1' || pid === 'custom-2';
        const customCfg = isCustom ? customProviders[Object.keys(customProviders)[CUSTOM_PROVIDER_IDS.indexOf(pid)]] : null;

        return (
          <button
            key={pid}
            onClick={() => setActiveProvider(pid)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer shrink-0 ${activeProvider === pid ? info.color : 'bg-zinc-900 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-zinc-200'}`}
            title={info.name}
          >
            <span className="w-2 h-2 rounded-full bg-zinc-700 shrink-0"></span>
            <span className="truncate max-w-[90px]">{isCustom && customCfg ? customCfg.name : info.name}</span>
            {!hasKey && (
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 shrink-0" title="No API key" />
            )}
          </button>
        );
      })}
    </div>
  );
};
