import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Download, Upload, X, GripVertical, Sparkles } from 'lucide-react';
import type { ProviderId, ProviderConfig } from '@/types';
import { BUILTIN_PROVIDERS, CUSTOM_PROVIDER_IDS, PROVIDER_DISPLAY } from '@/types';
import { getProviderConfigs, setProviderConfigs } from '@/lib/storage';

interface CascadeEditorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CascadeEditor: React.FC<CascadeEditorProps> = ({ isOpen, onClose }) => {
  const [configs, setConfigsState] = useState<Record<string, ProviderConfig>>({});
  const [activeTab, setActiveTab] = useState<ProviderId>('gemini');
  const [newModelInput, setNewModelInput] = useState('');
  const [addPosition, setAddPosition] = useState<'top' | 'end'>('top');
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    setConfigsState(getProviderConfigs());
    setActiveTab('gemini');
    setNotice(null);
  }, [isOpen]);

  const allProviderIds: ProviderId[] = [...BUILTIN_PROVIDERS.map((p) => p.id as ProviderId), ...CUSTOM_PROVIDER_IDS];

  const handleAddModel = () => {
    const trimmed = newModelInput.trim();
    if (!trimmed) return;
    const current = configs[activeTab]?.cascade || [];
    if (current.includes(trimmed)) {
      setNotice(`${trimmed} is already in ${activeTab}.`);
      return;
    }
    const next = addPosition === 'top' ? [trimmed, ...current] : [...current, trimmed];
    saveConfig(activeTab, { ...configs[activeTab], cascade: next });
    setNewModelInput('');
    setNotice(`Added ${trimmed} to ${activeTab}.`);
  };

  const handleDeleteModel = (modelId: string) => {
    const current = configs[activeTab]?.cascade || [];
    saveConfig(activeTab, { ...configs[activeTab], cascade: current.filter((m) => m !== modelId) });
    setNotice(`Removed ${modelId} from ${activeTab}.`);
  };

  const saveConfig = (pid: ProviderId, cfg: ProviderConfig) => {
    const next = { ...configs, [pid]: cfg };
    setConfigsState(next);
    setProviderConfigs(next);
  };

  const handleExport = () => {
    const payload = { cascades: configs, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cascade-config-${Date.now()}.json`;
    document.body.appendChild(a);
    (a as HTMLAnchorElement).click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setNotice('Exported cascade config.');
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (parsed.cascades && typeof parsed.cascades === 'object') {
        setProviderConfigs(parsed.cascades as Record<string, ProviderConfig>);
        setConfigsState(parsed.cascades as Record<string, ProviderConfig>);
        setNotice('Imported cascade config.');
      } else {
        setNotice('Invalid config file.');
      }
    } catch {
      setNotice('Invalid JSON file.');
    }
    e.target.value = '';
  };



  return (
    !isOpen ? null : (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
        <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-3xl p-5 shadow-2xl text-zinc-100 max-h-[90vh] flex flex-col">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3 shrink-0">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              <div>
                <h3 className="font-bold text-zinc-100 text-sm">Model Cascades</h3>
                <p className="text-[11px] text-zinc-500">Drag model cards to reorder. Empty = no default models.</p>
              </div>
            </div>
            <button onClick={onClose} className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"><X className="w-4 h-4" /></button>
          </div>

          <div className="p-2.5 rounded-xl bg-zinc-900/70 border border-zinc-800 text-[11px] text-zinc-400 leading-relaxed shrink-0 mb-2">
            Each provider has ONE cascade list. Models are called in order. Add custom slugs manually if not listed.
          </div>

          <div className="flex flex-wrap gap-1 mb-3">
            {allProviderIds.map((pid) => {
              const info = PROVIDER_DISPLAY[pid];
              const cascadeLen = (configs[pid]?.cascade || []).length;
              return (
                <button
                  key={pid}
                  onClick={() => setActiveTab(pid)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${activeTab === pid ? info.color : 'bg-zinc-900 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-zinc-200'}`}
                >
                  {info.name} ({cascadeLen})
                </button>
              );
            })}
          </div>

          <div className="flex-1 min-h-0 overflow-y-auto pr-1 scrollbar-thin mb-3">
            <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={newModelInput}
                  onChange={(e) => setNewModelInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleAddModel(); }}
                  placeholder="Enter model ID (e.g. gemini-1.5-flash, llama-3.3-70b-versatile)"
                  className="flex-1 px-3 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-cyan-500/60"
                />
                <select value={addPosition} onChange={(e) => setAddPosition(e.target.value as 'top' | 'end')} className="px-2 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[11px] text-zinc-300 focus:outline-none">
                  <option value="top">Top</option>
                  <option value="end">End</option>
                </select>
                <button onClick={handleAddModel} disabled={!newModelInput.trim()} className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-xs font-semibold text-white transition-colors flex items-center gap-1 cursor-pointer"><Plus className="w-3.5 h-3.5" /><span>Add</span></button>
              </div>
              {notice && <p className="text-[11px] text-amber-300">{notice}</p>}
            </div>

            <div className="space-y-1.5">
              {(() => {
                const list = configs[activeTab]?.cascade || [];
                if (list.length === 0) {
                  return (
                    <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-200 text-xs text-center">
                      Empty cascade — add models above. No defaults are baked in.
                    </div>
                  );
                }
                return (
                  <div>
                    {list.map((modelId, idx) => (
                      <div key={modelId} className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700 transition-colors cursor-grab select-none">
                        <div className="flex items-center gap-2 min-w-0">
                          <GripVertical className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
                          <span className="text-[10px] font-mono text-zinc-500 w-5 text-right shrink-0">#{idx + 1}</span>
                          <span className="font-mono text-xs text-zinc-200 truncate">{modelId}</span>
                        </div>
                        <button onClick={() => handleDeleteModel(modelId)} className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer" title={`Delete ${modelId}`}><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </div>
          </div>

          <div className="pt-2 border-t border-zinc-800 flex items-center justify-between gap-2 flex-wrap shrink-0">
            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={handleExport} className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-medium text-zinc-200 transition-colors flex items-center gap-1.5"><Download className="w-3.5 h-3.5 text-cyan-400" /><span>Export</span></button>
              <input ref={null as any} type="file" accept=".json" onChange={handleImport} className="hidden" />
              <button onClick={() => (document.querySelector('input[type="file"]') as HTMLInputElement)?.click()} className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-medium text-zinc-200 transition-colors flex items-center gap-1.5"><Upload className="w-3.5 h-3.5 text-emerald-400" /><span>Import</span></button>
            </div>
            <button onClick={onClose} className="px-4 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-100 transition-colors cursor-pointer">Done</button>
          </div>
        </div>
      </div>
    )
  );
};
