import React from 'react';
import { MessageBubble } from './MessageBubble';
import type { ChatMessage } from '@/types';

interface ChatCanvasProps {
  messages: ChatMessage[];
  activeModelUsed: string;
  isLoading: boolean;
  activeStreamingText: string;
  activeStreamingThought: string;
  isThinkingActive: boolean;
  fallbackNotice: string | null;
  speakingMessageId: string | null;
  isPaused: boolean;
  onCopyMarkdown: (text: string) => void;
  onCopyText: (text: string) => void;
  onReadAloud: (text: string, id: string) => void;
  onPauseResume: () => void;
  onStopReadAloud: () => void;
  onEditQuery: (msg: ChatMessage) => void;
  onDeleteMessage: (id: string) => void;
  editingMessageId: string | null;
  setEditingMessageId: (id: string | null) => void;
  editText: string;
  setEditText: (t: string) => void;
  onSaveResend: (id: string) => void;
}

export const ChatCanvas: React.FC<ChatCanvasProps> = ({
  messages, activeModelUsed, isLoading, activeStreamingText, activeStreamingThought,
  isThinkingActive, fallbackNotice, speakingMessageId, isPaused,
  onCopyMarkdown, onCopyText, onReadAloud, onPauseResume, onStopReadAloud,
  onEditQuery, onDeleteMessage, editingMessageId, setEditingMessageId,
  editText, setEditText, onSaveResend,
}) => {
  return (
    <main className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-6 bg-black">
      {fallbackNotice && (
        <div className="max-w-4xl mx-auto p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-amber-300 flex items-center gap-2 animate-in fade-in">
          <span className="w-4 h-4 text-amber-400">⚡</span>
          <span>{fallbackNotice}</span>
        </div>
      )}
      <div className="max-w-4xl mx-auto space-y-6">
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            msg={msg}
            isUser={msg.role === 'user'}
            speakingMessageId={speakingMessageId}
            isPaused={isPaused}
            onCopyMarkdown={onCopyMarkdown}
            onCopyText={onCopyText}
            onReadAloud={onReadAloud}
            onPauseResume={onPauseResume}
            onStopReadAloud={onStopReadAloud}
            onEditQuery={onEditQuery}
            onDeleteMessage={onDeleteMessage}
            editingMessageId={editingMessageId}
            setEditingMessageId={setEditingMessageId}
            editText={editText}
            setEditText={setEditText}
            onSaveResend={onSaveResend}
          />
        ))}
        {isLoading && (activeStreamingText || activeStreamingThought || isThinkingActive) && (
          <div className="flex flex-col items-start group">
            <div className="flex items-center gap-2 mb-1 px-1 text-[11px] text-zinc-500">
              <span className="font-semibold text-cyan-400 flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" /></span>
              <span>Generating...</span>
              <span className="px-1.5 py-0.2 rounded bg-zinc-900 border border-zinc-800 text-zinc-400 text-[10px]">{activeModelUsed}</span>
            </div>
            <div className="relative p-5 rounded-2xl max-w-[94%] sm:max-w-[85%] bg-[#09090b] border border-cyan-500/30 text-zinc-200 rounded-tl-sm shadow-xl">
              {activeStreamingThought && (
                <div className="mb-3 rounded-xl border border-purple-500/40 bg-purple-950/20 p-2.5 text-xs text-zinc-400">
                  <div className="flex items-center gap-2 font-medium text-zinc-300 hover:text-white w-full text-left cursor-pointer">
                    <span className="text-sm">🧠</span>
                    <span className="text-[11px] uppercase tracking-wider font-semibold flex-1 flex items-center gap-1.5 text-purple-300">Thinking Process</span>
                    <span className="text-[10px] text-zinc-500">▼ Show</span>
                  </div>
                  <div className="mt-2.5 pl-3 border-l-2 border-purple-500/50 text-zinc-300 leading-relaxed text-[11px] max-h-72 overflow-y-auto font-mono/relaxed bg-black/30 p-2 rounded-r-lg">{activeStreamingThought}</div>
                </div>
              )}
              {isThinkingActive && !activeStreamingThought && !activeStreamingText && (
                <div className="flex items-center gap-2 text-xs text-purple-400 animate-pulse mb-3 p-2 rounded-lg bg-purple-950/20 border border-purple-500/30"><span className="text-sm">🧠</span><span className="font-semibold">Thinking...</span></div>
              )}
              {activeStreamingText ? <div className="study-prose text-zinc-200 leading-relaxed break-words" dangerouslySetInnerHTML={{ __html: activeStreamingText }} /> : (!activeStreamingThought && <div className="w-6 h-1 bg-cyan-500/50 rounded animate-pulse" />)}
            </div>
          </div>
        )}
        {isLoading && !activeStreamingText && !activeStreamingThought && !isThinkingActive && (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-zinc-900 border border-zinc-800 max-w-md">
            <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin shrink-0" />
            <div className="text-xs text-zinc-300"><p className="font-semibold text-zinc-200">Consulting {activeModelUsed}...</p></div>
          </div>
        )}
      </div>
    </main>
  );
};
