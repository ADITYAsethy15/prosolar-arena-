import React, { useCallback } from 'react';
import { Paperclip, X, Send, Pause, Search, Globe } from 'lucide-react';
import type { AttachmentItem } from '@/types';

interface ComposerProps {
  inputPrompt: string;
  setInputPrompt: (v: string) => void;
  pendingAttachments: AttachmentItem[];
  setPendingAttachments: (v: AttachmentItem[] | ((prev: AttachmentItem[]) => AttachmentItem[])) => void;
  removePendingAttachment: (id: string) => void;
  isLoading: boolean;
  onStopStreaming: () => void;
  onSend: () => void;
  onAttach: () => void;
  onInsertMiniPrompt: (snippet: string) => void;
  onToggleWebSearch: () => void;
  webSearchEnabled: boolean;
  onToggleStreaming: () => void;
  streamingEnabled: boolean;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
  textareaRef: React.RefObject<HTMLTextAreaElement | null>;
  disabled: boolean;
}

const MAX_FILE_SIZE_MB = 25;

export const Composer: React.FC<ComposerProps> = ({
  inputPrompt, setInputPrompt,
  pendingAttachments, setPendingAttachments, removePendingAttachment,
  isLoading, onStopStreaming, onSend, onAttach,
  onInsertMiniPrompt, onToggleWebSearch, webSearchEnabled,
  onToggleStreaming, streamingEnabled,
  fileInputRef, textareaRef, disabled,
}) => {
  const handlePaste = useCallback((e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    if (e.clipboardData.files && e.clipboardData.files.length > 0) {
      e.preventDefault();
      const files = Array.from(e.clipboardData.files);
      const newAttachments: AttachmentItem[] = [];
      for (const file of files) {
        if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
          alert(`File "${file.name}" exceeds ${MAX_FILE_SIZE_MB}MB limit.`);
          continue;
        }
        const reader = new FileReader();
        reader.onload = (ev) => {
          const dataUrl = (ev?.target?.result as string) || '';
          const base64 = dataUrl.split(',')[1] || '';
          const mime = file.type || (file.name.endsWith('.pdf') ? 'application/pdf' : 'text/plain');
          newAttachments.push({
            id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            name: file.name,
            mimeType: mime,
            size: file.size,
            dataUrl,
            base64,
          });
        };
        reader.readAsDataURL(file);
      }
      setPendingAttachments((prev) => [...prev, ...newAttachments]);
    }
  }, [setPendingAttachments]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputPrompt(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  };

  return (
    <footer className="shrink-0 p-3 sm:p-4 bg-black border-t border-zinc-800 z-20">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between gap-2 mb-2 text-xs">
          <div className="flex items-center gap-2">
            <button onClick={() => onInsertMiniPrompt('Explain step by step: ')} className="p-1.5 rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-cyan-300 transition-colors cursor-pointer text-[11px]" title="Mini prompt">
              <span className="text-[12px] font-bold">※</span>
            </button>
            <button onClick={onToggleWebSearch} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${webSearchEnabled ? 'bg-cyan-950/90 border border-cyan-500 text-cyan-200 shadow-[0_0_12px_rgba(6,182,212,0.35)]' : 'bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-zinc-200'}`} title="Web search (Tavily)">
              <Search className="w-3.5 h-3.5" /><span>Web Search</span>
            </button>
            <button onClick={onToggleStreaming} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${streamingEnabled ? 'bg-cyan-950/90 border border-cyan-500 text-cyan-200' : 'bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-zinc-200'}`} title="Streaming">
              <Globe className="w-3.5 h-3.5" /><span>Stream</span>
            </button>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-zinc-500 text-[11px] font-medium">Max {MAX_FILE_SIZE_MB}MB</span>
          </div>
        </div>

        {pendingAttachments.length > 0 && (
          <div className="mb-2 p-2 rounded-xl bg-zinc-900 border border-zinc-800 flex flex-wrap gap-2 items-center">
            {pendingAttachments.map((att) => (
              <div key={att.id} className="flex items-center gap-2 p-1.5 pl-2 pr-1.5 rounded-lg bg-black border border-zinc-800 text-xs text-zinc-200 group">
                {att.mimeType.startsWith('image/') ? (
                  <img src={att.dataUrl} alt={att.name} className="w-6 h-6 object-cover rounded" />
                ) : (
                  <div className="w-4 h-4 text-cyan-400">📄</div>
                )}
                <span className="max-w-[130px] truncate text-[11px] font-medium">{att.name}</span>
                <button onClick={() => removePendingAttachment(att.id)} className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-rose-400 transition-colors" title="Remove"><X className="w-3 h-3" /></button>
              </div>
            ))}
            <span className="text-[11px] text-zinc-500 ml-1">{pendingAttachments.length} file(s)</span>
          </div>
        )}

        <div className="relative flex items-end gap-2 bg-[#09090b] border border-zinc-800 rounded-2xl p-2 focus-within:border-zinc-600 shadow-inner">
          <input
            ref={fileInputRef as React.LegacyRef<HTMLInputElement>}
            type="file"
            multiple
            accept="image/*,application/pdf,text/*"
            onChange={(e) => {
              if (e.target.files) {
                const newAttachments: AttachmentItem[] = [];
                for (const file of Array.from(e.target.files)) {
                  if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) { alert(`File "${file.name}" exceeds ${MAX_FILE_SIZE_MB}MB limit.`); continue; }
                  const reader = new FileReader();
                  reader.onload = (ev) => {
                    const dataUrl = (ev?.target?.result as string) || '';
                    const base64 = dataUrl.split(',')[1] || '';
                    const mime = file.type || 'application/octet-stream';
                    newAttachments.push({
                      id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
                      name: file.name,
                      mimeType: mime,
                      size: file.size,
                      dataUrl,
                      base64,
                    });
                  };
                  reader.readAsDataURL(file);
                }
                setPendingAttachments((prev) => [...prev, ...newAttachments]);
                e.target.value = '';
              }
            }}
            className="hidden"
          />
          <button onClick={onAttach} className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-zinc-100 transition-colors shrink-0 cursor-pointer" title="Upload file"><Paperclip className="w-4 h-4" /></button>

          <textarea
            ref={textareaRef as React.LegacyRef<HTMLTextAreaElement>}
            value={inputPrompt}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            rows={1}
            disabled={disabled}
            placeholder={disabled ? 'Enter API keys in Settings to start...' : 'Type your message...'}
            className="flex-1 max-h-44 bg-transparent text-zinc-100 placeholder-zinc-500 text-sm px-2 py-1.5 focus:outline-none resize-none leading-relaxed disabled:opacity-40 disabled:cursor-not-allowed"
          />

          {isLoading ? (
            <button onClick={onStopStreaming} className="p-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/70 text-amber-300 hover:text-amber-200 font-bold transition-all shrink-0 cursor-pointer" title="Stop"><Pause className="w-4 h-4 fill-amber-300" /></button>
          ) : (
            <button onClick={onSend} disabled={disabled || (!inputPrompt.trim() && pendingAttachments.length === 0)} className="p-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 disabled:hover:bg-zinc-800 text-white font-bold transition-all shrink-0 border border-zinc-700 cursor-pointer" title="Send"><Send className="w-4 h-4" /></button>
          )}
        </div>
      </div>
    </footer>
  );
};
