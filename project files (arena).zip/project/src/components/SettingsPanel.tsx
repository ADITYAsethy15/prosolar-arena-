import React from 'react';
import type { AppSettings } from '@/types';
import { HISTORY_LIMIT_STEPS } from '@/types';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (s: AppSettings) => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  isOpen, onClose, settings, onUpdateSettings,
}) => {
  const [maxTokens, setMaxTokens] = React.useState(settings.maxTokens);
  const [historyLimit, setHistoryLimit] = React.useState(settings.historyLimit);

  React.useEffect(() => { setMaxTokens(settings.maxTokens); setHistoryLimit(settings.historyLimit); }, [settings.maxTokens, settings.historyLimit]);

  return (
    !isOpen ? null : (
      <div
        onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in"
      >
        <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-md p-4 shadow-2xl text-zinc-100 animate-in zoom-in duration-200 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-zinc-100 text-sm">Settings</h3>
            <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200">✕</button>
          </div>
          <div className="space-y-4 mb-4">
            <div>
              <label className="block text-xs text-zinc-400 mb-1">Max Tokens (500 - 100000)</label>
              <input
                type="number"
                min={500} max={100000}
                value={maxTokens}
                onChange={(e) => {
                  const v = Math.min(100000, Math.max(500, parseInt(e.target.value) || 500));
                  setMaxTokens(v);
                  onUpdateSettings({ ...settings, maxTokens: v });
                }}
                className="w-full px-3 py-2 rounded-lg bg-black border border-zinc-800 text-zinc-100 focus:outline-none focus:border-cyan-500/50 transition-colors text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-zinc-400 mb-1">History Limit (last N messages sent)</label>
              <select value={historyLimit} onChange={(e) => {
                const v = parseInt(e.target.value);
                setHistoryLimit(v);
                onUpdateSettings({ ...settings, historyLimit: v });
              }} className="w-full px-3 py-2 rounded-lg bg-black border border-zinc-800 text-zinc-100 focus:outline-none focus:border-cyan-500/50 transition-colors text-sm">
                {HISTORY_LIMIT_STEPS.map((s) => (
                  <option key={s} value={s}>Last {s}</option>
                ))}
              </select>
            </div>
            <label className="flex items-center gap-2 text-xs text-zinc-400 cursor-pointer">
              <input type="checkbox" checked={settings.streaming} onChange={(e) => onUpdateSettings({ ...settings, streaming: e.target.checked })} className="rounded bg-zinc-900 border-zinc-700 text-cyan-600 focus:ring-cyan-500" />
              Enable streaming responses
            </label>
          </div>
          <div className="mt-3 pt-2 border-t border-zinc-800 text-[10px] text-zinc-500 text-center">
            All settings saved in localStorage only.
          </div>
        </div>
      </div>
    )
  );
};
