import React from 'react';
import { Trash2, Clock } from 'lucide-react';
import type { ChatSession } from '@/types';
import { getSessions, setSessions, getActiveSessionId, setActiveSessionId } from '@/lib/storage';

interface ChatHistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadSession: (session: ChatSession) => void;
  onNewSession: () => void;
}

export const ChatHistoryDrawer: React.FC<ChatHistoryDrawerProps> = ({
  isOpen, onClose, onLoadSession, onNewSession,
}) => {
  const [sessions, setSessionsState] = React.useState<ChatSession[]>([]);

  React.useEffect(() => {
    setSessionsState(getSessions());
  }, [isOpen]);

  const activeId = getActiveSessionId();

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const next = sessions.filter((s) => s.id !== id);
    setSessions(next);
    setSessions(next);
    if (activeId === id) setActiveSessionId(null);
  };

  return (
    !isOpen ? null : (
      <div
        onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in"
      >
        <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-md p-4 shadow-2xl text-zinc-100 animate-in zoom-in duration-200 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-zinc-100 text-sm">Chat History</h3>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={onNewSession} className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 transition-colors border border-zinc-700">New Chat</button>
              <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200">✕</button>
            </div>
          </div>
          <p className="text-[11px] text-zinc-500 mb-3">Up to last 10 chats. Saved in localStorage only.</p>
          <div className="flex-1 min-h-0 overflow-y-auto pr-1 space-y-2 scrollbar-thin">
            {sessions.length === 0 ? (
              <div className="text-center py-6 text-xs text-zinc-500">
                No saved chats yet. Start a new conversation.
              </div>
            ) : (
              sessions.map((session) => (
                <div key={session.id} onClick={() => { onLoadSession(session); onClose(); }} className="flex items-center justify-between px-3 py-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800/50 transition-colors cursor-pointer group">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-zinc-200 truncate">{session.title || 'Untitled'}</span>
                      {activeId === session.id && <span className="w-2 h-2 rounded-full bg-cyan-500 shrink-0" /> }
                    </div>
                    <span className="text-[10px] text-zinc-500">{new Date(session.updatedAt).toLocaleDateString()} {new Date(session.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <button onClick={(e) => handleDelete(e, session.id)} className="p-1 text-zinc-500 hover:text-rose-400 hover:bg-rose-950/20 rounded transition-colors"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))
            )}
          </div>
          <div className="mt-3 pt-2 border-t border-zinc-800 text-[10px] text-zinc-500 text-center">
            Chats are stored locally in your browser — nothing is sent to a cloud server.
          </div>
        </div>
      </div>
    )
  );
};
