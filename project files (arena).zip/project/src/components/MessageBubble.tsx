import React from 'react';
import { MarkdownRenderer } from './MarkdownRenderer';
import { Copy, Edit3, Volume2, VolumeX, Pause, Play, Send, ShieldCheck } from 'lucide-react';
import type { ChatMessage } from '@/types';

interface MessageBubbleProps {
  msg: ChatMessage;
  isUser: boolean;
  speakingMessageId: string | null;
  isPaused: boolean;
  onCopyMarkdown: (text: string) => void;
  onCopyText: (text: string) => void;
  onReadAloud: (text: string, id: string) => void;
  onPauseResume: () => void;
  onStopReadAloud: () => void;
  onEditQuery: (msg: ChatMessage) => void;
  onDeleteMessage: (id: string) => void;
  editingMessageId: string | null;
  setEditingMessageId: (id: string | null) => void;
  editText: string;
  setEditText: (t: string) => void;
  onSaveResend: (id: string) => void;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  msg, isUser, speakingMessageId, isPaused,
  onCopyMarkdown, onCopyText, onReadAloud, onPauseResume,
  onEditQuery, onDeleteMessage, editingMessageId, setEditingMessageId,
  editText, setEditText, onSaveResend,
}) => {
  const handleCopyText = () => {
    const plain = msg.text.replace(/\[(\d+)\]/g, '').replace(/\*\*/g, '').replace(/`/g, '');
    onCopyText(plain);
  };

  if (isUser && editingMessageId === msg.id) {
    return (
      <div key={msg.id} className="flex flex-col items-end group">
        <div className="flex items-center justify-between mb-1 px-1 text-[11px] text-zinc-500 w-full max-w-[94%] sm:max-w-[85%]">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-zinc-400">You</span>
            <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
          <button onClick={() => setEditingMessageId(null)} className="opacity-40 hover:opacity-100 p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-cyan-300 cursor-pointer">
            <Edit3 className="w-3 h-3" />
          </button>
        </div>
        <div className="relative p-5 rounded-2xl max-w-[94%] sm:max-w-[85%] bg-zinc-900 border border-zinc-800 text-zinc-100 rounded-tr-sm">
          <div className="space-y-2.5 pt-1">
            <textarea
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); onSaveResend(msg.id); }
                else if (e.key === 'Escape') setEditingMessageId(null);
              }}
              rows={Math.max(2, Math.min(8, editText.split('\n').length + 1))}
              className="w-full p-2.5 bg-black border border-cyan-500/70 rounded-xl text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none leading-relaxed resize-y font-normal autoFocus"
              placeholder="Edit your prompt..."
            />
            <div className="flex items-center justify-between text-xs">
              <span className="text-[10px] text-zinc-500 font-mono">Ctrl+Enter to save & resend • Esc to cancel</span>
              <div className="flex items-center gap-1.5">
                <button onClick={() => setEditingMessageId(null)} className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium cursor-pointer transition-colors">Cancel</button>
                <button onClick={() => onSaveResend(msg.id)} disabled={!editText.trim()} className="px-3 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-black font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors shadow-sm"><Send className="w-3 h-3" /><span>Save & Resend</span></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div key={msg.id} className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} group`}>
      <div className="flex items-center justify-between mb-1 px-1 text-[11px] text-zinc-500 w-full max-w-[94%] sm:max-w-[85%]">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-zinc-400">{isUser ? 'You' : 'Assistant'}</span>
          {msg.modelUsed && !isUser && (
            <span className="px-1.5 py-0.2 rounded bg-zinc-900 border border-zinc-800 text-zinc-400 text-[10px]">{msg.modelUsed}</span>
          )}
          <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
        <div className="flex items-center gap-1">
          {isUser && editingMessageId !== msg.id && (
            <button onClick={() => onEditQuery(msg)} className="opacity-40 hover:opacity-100 transition-opacity p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-cyan-300 cursor-pointer" title="Edit prompt">
              <Edit3 className="w-3 h-3" />
            </button>
          )}
          {editingMessageId === msg.id ? null : (
            <button onClick={() => { const id = msg.id; const el = document.getElementById(`del-${id}`); if(el) el.style.display = el.style.display === 'none' ? 'flex' : 'none'; }} className="opacity-40 hover:opacity-100 transition-opacity p-0.5 rounded hover:bg-zinc-800 text-xs" title="Delete message" style={{ fontSize: '11px' }}>🗑️</button>
          )}
          {editingMessageId === msg.id ? null : (
            <div id={`del-${msg.id}`} style={{ display: 'none' }} className="flex items-center gap-1 bg-rose-950/90 border border-rose-500/50 px-2 py-0.5 rounded text-[10px] text-rose-200 shadow-lg absolute right-0 top-8">
              <span>Delete?</span>
              <button onClick={() => onDeleteMessage(msg.id)} className="text-white font-bold px-1.5 py-0.2 bg-rose-600 rounded hover:bg-rose-500">Yes</button>
              <button onClick={() => { document.getElementById(`del-${msg.id}`)!.style.display = 'none'; }} className="text-zinc-300 px-1.5 py-0.2 bg-zinc-800 rounded hover:bg-zinc-700">No</button>
            </div>
          )}
        </div>
      </div>

      <div className={`relative p-5 rounded-2xl max-w-[94%] sm:max-w-[85%] transition-all ${isUser ? 'bg-zinc-900 border border-zinc-800 text-zinc-100 rounded-tr-sm' : 'bg-[#09090b] border border-zinc-800/90 text-zinc-200 rounded-tl-sm'}`}>
        {msg.attachments && msg.attachments.length > 0 && (
          <div className="mb-3.5 flex flex-wrap gap-2.5">
            {msg.attachments.map((att) => (
              <div key={att.id} className="relative group/att rounded-xl overflow-hidden border border-zinc-800 bg-black max-w-[200px]">
                {att.mimeType.startsWith('image/') ? (
                  <div onClick={() => { window.open(att.dataUrl, '_blank'); }} className="cursor-pointer relative overflow-hidden">
                    <img src={att.dataUrl} alt={att.name} className="h-28 w-full object-cover rounded-lg" />
                  </div>
                ) : (
                  <div className="p-3 flex items-center gap-2">
                    <div className="w-5 h-5 text-cyan-400">📄</div>
                    <div className="text-[11px]"><p className="font-semibold text-zinc-200 truncate">{att.name}</p><p className="text-zinc-500 uppercase text-[10px]">{att.mimeType.split('/')[1] || 'DOC'}</p></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {isUser ? (
          <div className="text-[16.5px] leading-relaxed font-normal"><MarkdownRenderer content={msg.text} /></div>
        ) : (
          <div>
            {msg.thought && (
              <div className="mb-3 rounded-xl border border-purple-500/40 bg-purple-950/20 p-2.5 text-xs text-zinc-400">
                <button onClick={() => {}} className="flex items-center gap-2 font-medium text-zinc-300 hover:text-white transition-colors w-full text-left cursor-pointer">
                  <span className="text-sm">🧠</span>
                  <span className="text-[11px] uppercase tracking-wider font-semibold flex-1 flex items-center gap-1.5 text-purple-300">Thinking Process</span>
                </button>
                <div className="mt-2.5 pl-3 border-l-2 border-purple-500/50 text-zinc-300 leading-relaxed text-[11px] max-h-72 overflow-y-auto font-mono/relaxed bg-black/30 p-2 rounded-r-lg">{msg.thought}</div>
              </div>
            )}
            <MarkdownRenderer content={msg.text} />
          </div>
        )}

        <div className="mt-3.5 pt-2.5 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400">
          <div className="flex items-center gap-2">
            <button onClick={() => onCopyMarkdown(msg.text)} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-colors text-xs cursor-pointer" title="Copy markdown">
              <Copy className="w-3.5 h-3.5" /><span>Copy Markdown</span>
            </button>
            {isUser && (
              <button onClick={handleCopyText} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-colors text-xs cursor-pointer" title="Copy plain text">
                <Copy className="w-3.5 h-3.5" /><span>Copy Text</span>
              </button>
            )}
            {!isUser && (
              <>
                <button onClick={() => onReadAloud(msg.text, msg.id)} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-colors text-xs cursor-pointer" title="Read aloud">
                  {speakingMessageId === msg.id ? <VolumeX className="w-3.5 h-3.5 text-rose-400 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5 text-cyan-400" />}
                  {speakingMessageId === msg.id ? <span className="text-rose-400 font-medium">Stop Audio</span> : <span>Read Aloud</span>}
                </button>
                {speakingMessageId === msg.id && (
                  <button onClick={onPauseResume} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-colors text-xs cursor-pointer" title={isPaused ? 'Resume' : 'Pause'}>
                    {isPaused ? <Play className="w-3.5 h-3.5 text-emerald-400" /> : <Pause className="w-3.5 h-3.5 text-amber-400" />}
                    <span className={isPaused ? 'text-emerald-400 font-medium' : 'text-amber-400 font-medium'}>{isPaused ? 'Resume' : 'Pause'}</span>
                  </button>
                )}
              </>
            )}
          </div>
          {!isUser && (
            <span className="text-[11px] text-zinc-500 flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5 text-emerald-500/70" /> Ready</span>
          )}
        </div>
      </div>
    </div>
  );
};
