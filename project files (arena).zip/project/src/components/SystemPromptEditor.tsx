import React from 'react';

interface SystemPromptEditorProps {
  isOpen: boolean;
  onClose: () => void;
  currentPrompt: string;
  onUpdate: (prompt: string) => void;
}

export const SystemPromptEditor: React.FC<SystemPromptEditorProps> = ({
  isOpen, onClose, currentPrompt, onUpdate,
}) => {
  const [text, setText] = React.useState(currentPrompt);

  React.useEffect(() => { setText(currentPrompt); }, [currentPrompt]);

  const handleSave = () => {
    onUpdate(text);
    onClose();
  };

  return (
    !isOpen ? null : (
      <div
        onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in"
      >
        <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-2xl p-4 shadow-2xl text-zinc-100 animate-in zoom-in duration-200 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-zinc-100 text-sm">System Prompt</h3>
            <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200">✕</button>
          </div>
          <p className="text-[11px] text-zinc-500 mb-3">Editable system prompt. Saved in localStorage only. Sent with every request.</p>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={14}
            className="w-full px-3 py-2 rounded-lg bg-black border border-zinc-800 text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-cyan-500/50 transition-colors text-sm font-mono resize-y"
            placeholder="Enter your system prompt..."
          />
          <div className="mt-3 flex items-center justify-end gap-2">
            <button onClick={onClose} className="px-4 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 transition-colors border border-zinc-700">Cancel</button>
            <button onClick={handleSave} className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-black font-semibold text-xs transition-colors shadow-sm">Save</button>
          </div>
        </div>
      </div>
    )
  );
};
