import React from 'react';

interface TavilySettingsProps {
  isOpen: boolean;
  onClose: () => void;
  settings: any;
  onUpdate: (s: any) => void;
}

export const TavilySettings: React.FC<TavilySettingsProps> = ({
  isOpen, onClose, settings, onUpdate,
}) => {
  const [tavilyKey, setTavilyKey] = React.useState(settings.tavilyApiKey);

  React.useEffect(() => { setTavilyKey(settings.tavilyApiKey); }, [settings.tavilyApiKey]);

  const handleSave = () => {
    onUpdate({ ...settings, tavilyApiKey: tavilyKey });
    onClose();
  };

  return (
    !isOpen ? null : (
      <div
        onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in"
      >
        <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-md p-4 shadow-2xl text-zinc-100 animate-in zoom-in duration-200 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-zinc-100 text-sm">Tavily Web Search</h3>
            <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200">✕</button>
          </div>
          <p className="text-[11px] text-zinc-500 mb-3">API key stored in localStorage only.</p>
          <div className="space-y-3 mb-4">
            <div>
              <label className="block text-xs text-zinc-400 mb-1">Tavily API Key</label>
              <input
                type="password"
                value={tavilyKey}
                onChange={(e) => setTavilyKey(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black border border-zinc-800 text-zinc-100 focus:outline-none focus:border-cyan-500/50 transition-colors text-sm"
                placeholder="tvly-..."
              />
            </div>
            <div>
              <label className="block text-xs text-zinc-400 mb-1">Search Depth</label>
              <select value={settings.tavilyDepth} onChange={(e) => onUpdate({ ...settings, tavilyDepth: e.target.value as any })} className="w-full px-3 py-2 rounded-lg bg-black border border-zinc-800 text-zinc-100 focus:outline-none focus:border-cyan-500/50 transition-colors text-sm">
                <option value="basic">Basic</option>
                <option value="advanced">Advanced</option>
                <option value="fast">Fast</option>
                <option value="ultra-fast">Ultra-fast</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-zinc-400 mb-1">Results per call (1-10)</label>
              <input
                type="number"
                min={1} max={10}
                value={settings.tavilyResults}
                onChange={(e) => onUpdate({ ...settings, tavilyResults: Math.min(10, Math.max(1, parseInt(e.target.value) || 1)) })}
                className="w-full px-3 py-2 rounded-lg bg-black border border-zinc-800 text-zinc-100 focus:outline-none focus:border-cyan-500/50 transition-colors text-sm"
              />
            </div>
          </div>
          <div className="mt-3 flex items-center justify-end gap-2">
            <button onClick={onClose} className="px-4 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 transition-colors border border-zinc-700">Cancel</button>
            <button onClick={handleSave} className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-black font-semibold text-xs transition-colors shadow-sm">Save</button>
          </div>
        </div>
      </div>
    )
  );
};
