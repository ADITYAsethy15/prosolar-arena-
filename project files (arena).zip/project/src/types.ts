export type ProviderId =
  | 'gemini'
  | 'groq'
  | 'openrouter'
  | 'nvidia'
  | 'zai'
  | 'custom-1'
  | 'custom-2';

export type ThinkingMode =
  | 'default'
  | 'none'
  | 'minimal'
  | 'low'
  | 'medium'
  | 'high'
  | 'xhigh'
  | 'max'
  | 'on';

export type AttachmentItem = {
  id: string;
  name: string;
  mimeType: string;
  size?: number;
  dataUrl?: string; // client-side preview only, never persisted
  base64?: string;   // raw base64 without header, sent to server
};

export type ChatMessage = {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  modelUsed?: string;
  thought?: string;
  attachments?: AttachmentItem[];
};

export type ChatSession = {
  id: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: number;
};

export type ProviderConfig = {
  name: string;
  baseUrl: string;
  apiKey: string;
  cascade: string[]; // ordered model IDs, empty by default
  thinkingMode: ThinkingMode;
  maxTokens: number;
};

export type AppSettings = {
  historyLimit: number; // 5, 10, 15, 20, 25, 30, 35, 40
  maxTokens: number;    // 500 - 100000
  streaming: boolean;
  thinkingMode: ThinkingMode;
  webSearch: boolean;
  tavilyApiKey: string;
  tavilyDepth: 'basic' | 'advanced' | 'fast' | 'ultra-fast';
  tavilyResults: number; // 1-10
  tavilyAllowSites: string;
  tavilyBlockSites: string;
  themeAccent: string;
  systemPrompt: string;
};

export type StreamEvent =
  | { type: 'model_init'; model: string }
  | { type: 'thinking' }
  | { type: 'thought'; text: string }
  | { type: 'chunk'; text: string }
  | { type: 'fallback_notice'; failedModel: string; nextModel: string; reason: string }
  | { type: 'done'; modelUsed: string }
  | { type: 'error'; error: string };

export type WireMessage = {
  role: 'user' | 'model';
  text: string;
  attachments?: AttachmentItem[];
};

// LocalStorage keys
export const LS_KEYS = {
  apiKeys: 'ai_api_keys',              // { [providerId]: string }
  customProviders: 'ai_custom_providers', // { [baseUrl]: { name, endpoint, apiKey } }
  providerConfigs: 'ai_provider_configs', // { [providerId]: ProviderConfig }
  settings: 'ai_settings',             // AppSettings
  sessions: 'ai_sessions',             // ChatSession[] (max 10)
  activeSessionId: 'ai_active_session', // string
} as const;

export const BUILTIN_PROVIDERS: { id: ProviderId; name: string; baseUrl: string; label: string }[] = [
  { id: 'gemini', name: 'Gemini AI Studio', baseUrl: 'https://generativelanguage.googleapis.com', label: 'Gemini' },
  { id: 'groq', name: 'Groq', baseUrl: 'https://api.groq.com/openai/v1', label: 'Groq' },
  { id: 'openrouter', name: 'OpenRouter', baseUrl: 'https://openrouter.ai/api/v1', label: 'OpenRouter' },
  { id: 'nvidia', name: 'NVIDIA NIM', baseUrl: 'https://integrate.api.nvidia.com/v1', label: 'NVIDIA' },
  { id: 'zai', name: 'Z.AI', baseUrl: 'https://api.z.ai/api/paas/v4', label: 'Z.AI' },
];

export const CUSTOM_PROVIDER_IDS: ProviderId[] = ['custom-1', 'custom-2'];

export const ALL_PROVIDERS: ProviderId[] = [
  'gemini', 'groq', 'openrouter', 'nvidia', 'zai', 'custom-1', 'custom-2',
];

export const HISTORY_LIMIT_STEPS = [5, 10, 15, 20, 25, 30, 35, 40];

export const DEFAULT_MAX_TOKENS = 8192;
export const STREAM_TIMEOUT_MS = 240_000; // 4 minutes
export const MAX_SESSIONS = 10;
export const MAX_FILE_SIZE_MB = 25;
export const EXPRESS_BODY_LIMIT_MB = 30;

export const PROVIDER_DISPLAY: Record<ProviderId, { name: string; color: string }> = {
  gemini: { name: 'Gemini AI Studio', color: 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300' },
  groq: { name: 'Groq', color: 'bg-orange-950/80 border-orange-500/50 text-orange-300' },
  openrouter: { name: 'OpenRouter', color: 'bg-purple-950/80 border-purple-500/50 text-purple-300' },
  nvidia: { name: 'NVIDIA NIM', color: 'bg-green-950/80 border-green-500/50 text-green-300' },
  zai: { name: 'Z.AI', color: 'bg-rose-950/80 border-rose-500/50 text-rose-300' },
  'custom-1': { name: 'Custom 1', color: 'bg-zinc-900 border-zinc-800 text-zinc-400' },
  'custom-2': { name: 'Custom 2', color: 'bg-zinc-900 border-zinc-800 text-zinc-400' },
};
