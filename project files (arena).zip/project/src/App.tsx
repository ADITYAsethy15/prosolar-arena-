import { useState, useEffect, useRef, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { ChatMessage, ChatSession, ProviderId, AppSettings } from '@/types';
import {
  getSessions, setSessions, getActiveSessionId, lsSetActiveSessionId,
  getProviderConfig, ensureProviderConfigs,
  getApiKeys, DEFAULT_SETTINGS,
} from '@/lib/storage';

import { ChatCanvas } from './components/ChatCanvas';
import { Composer } from './components/Composer';
import { CascadeEditor } from './components/CascadeEditor';
import { ChatHistoryDrawer } from './components/ChatHistoryDrawer';
import { SystemPromptEditor } from './components/SystemPromptEditor';
import { TavilySettings } from './components/TavilySettings';
import { SettingsPanel } from './components/SettingsPanel';
import { ProviderSwitcher } from './components/ProviderSwitcher';
import { MiniPromptDrawer } from './components/MiniPromptDrawer';

export default function App() {
  /* ---------- localStorage-backed state ---------- */
  const [sessions, setSessionsState] = useState<ChatSession[]>(() => getSessions());
  const [activeSessionId, setActiveSessionIdState] = useState<string | null>(() => getActiveSessionId());
  const [settings, setSettingsState] = useState<AppSettings>(() => DEFAULT_SETTINGS);
  const [apiKeys] = useState<Record<string, string>>(() => getApiKeys());

  /* ---------- UI state ---------- */
  const [activeProvider, setActiveProvider] = useState<ProviderId>('gemini');
  const [inputPrompt, setInputPrompt] = useState('');
  const [pendingAttachments, setPendingAttachments] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeStreamingText, setActiveStreamingText] = useState('');
  const [activeStreamingThought, setActiveStreamingThought] = useState('');
  const [isThinkingActive, setIsThinkingActive] = useState(false);
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);
  const [activeModelUsed, setActiveModelUsed] = useState('');
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  /* ---------- Modal states ---------- */
  const [isCascadeOpen, setIsCascadeOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isSystemPromptOpen, setIsSystemPromptOpen] = useState(false);
  const [isTavilyOpen, setIsTavilyOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isMiniPromptOpen, setIsMiniPromptOpen] = useState(false);


  /* ---------- Refs ---------- */
  const abortControllerRef = useRef<AbortController | null>(null);
  const isUserAbortedRef = useRef(false);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const currentSessionRef = useRef<ChatSession | null>(null);

  /* ---------- Derived ---------- */
  const currentSession = sessions.find((s) => s.id === activeSessionId) ?? null;
  const messages: ChatMessage[] = currentSession?.messages ?? [];
  const webSearchEnabled = settings.webSearch;
  const streamingEnabled = settings.streaming;

  /* ---------- Effects ---------- */
  useEffect(() => {
    ensureProviderConfigs();
  }, []);

  useEffect(() => {
    if (activeSessionId) {
      const sess = sessions.find((s) => s.id === activeSessionId);
      currentSessionRef.current = sess ?? null;
    }
  }, [activeSessionId, sessions]);

  /* Persist messages + bump session updatedAt when messages change */
  useEffect(() => {
    if (!currentSessionRef.current) return;
    const updatedSessions = sessions.map((s) =>
      s.id === currentSessionRef.current!.id
        ? { ...s, messages, updatedAt: Date.now() }
        : s
    );
    setSessionsState(updatedSessions);
    setSessions(updatedSessions);
    if (activeSessionId !== currentSessionRef.current!.id) {
      setActiveSessionIdState(currentSessionRef.current!.id);
    }
  }, [messages, sessions, currentSessionRef, activeSessionId]);

  /* ---------- Speech helpers ---------- */
  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    const handleVoicesChanged = () => window.speechSynthesis.getVoices();
    window.speechSynthesis.addEventListener('voiceschanged', handleVoicesChanged);
    window.speechSynthesis.getVoices();
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', handleVoicesChanged);
      window.speechSynthesis.cancel();
    };
  }, []);

  const speechQueueRef = useRef<{ messageId: string; chunks: string[]; currentIndex: number }>({ messageId: '', chunks: [], currentIndex: 0 });

  const playSpeechChunk = (index: number, chunks: string[], id: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (index >= chunks.length || speechQueueRef.current.messageId !== id) {
      setSpeakingMessageId(null);
      setIsPaused(false);
      speechQueueRef.current = { messageId: '', chunks: [], currentIndex: 0 };
      return;
    }
    const chunk = chunks[index];
    const utterance = new SpeechSynthesisUtterance(chunk);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find((v) => /samantha|victoria|karen|moira|zira|aria|jenny|google us english|en-us/i.test(v.name) && v.lang.startsWith('en')) || voices.find((v) => v.lang.startsWith('en-US')) || voices.find((v) => v.lang.startsWith('en'));
    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.onend = () => {
      if (speechQueueRef.current.messageId === id) {
        speechQueueRef.current.currentIndex = index + 1;
        playSpeechChunk(index + 1, chunks, id);
      }
    };
    utterance.onerror = () => {
      if (speechQueueRef.current.messageId === id) {
        speechQueueRef.current.currentIndex = index + 1;
        playSpeechChunk(index + 1, chunks, id);
      }
    };
    window.speechSynthesis.speak(utterance);
  };

  const handlePauseResume = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (window.speechSynthesis.paused || isPaused) { window.speechSynthesis.resume(); setIsPaused(false); }
    else { window.speechSynthesis.pause(); setIsPaused(true); }
  };

  const handleReadAloud = (rawText: string, id: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (speakingMessageId === id) { window.speechSynthesis.cancel(); setSpeakingMessageId(null); setIsPaused(false); speechQueueRef.current = { messageId: '', chunks: [], currentIndex: 0 }; return; }
    window.speechSynthesis.cancel();
    setIsPaused(false);
    const cleanText = rawText.replace(/\[(\d+)\]/g, '').replace(/\*\*/g, '').replace(/`/g, '').replace(/#{1,6}\s/g, '');
    if (!cleanText.trim()) return;
    const chunks = cleanText.match(/[^.!?\n]+[.!?\n]?/g) || [cleanText];
    speechQueueRef.current = { messageId: id, chunks, currentIndex: 0 };
    setSpeakingMessageId(id);
    playSpeechChunk(0, chunks, id);
  };

  const onStopReadAloud = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setSpeakingMessageId(null);
    setIsPaused(false);
    speechQueueRef.current = { messageId: '', chunks: [], currentIndex: 0 };
  };

  /* ---------- Session management ---------- */
  const createNewSession = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel();
    const newSession: ChatSession = { id: uuidv4(), title: 'New conversation', messages: [], updatedAt: Date.now() };
    const next = [newSession, ...sessions.filter((s) => s.id !== activeSessionId)].slice(0, 10);
    setSessionsState(next);
    setSessions(next);
    setActiveSessionIdState(newSession.id);
    lsSetActiveSessionId(newSession.id);
    currentSessionRef.current = newSession;
    setInputPrompt('');
    setPendingAttachments([]);
    setActiveStreamingText('');
    setActiveStreamingThought('');
    setIsThinkingActive(false);
    setFallbackNotice(null);
    setIsLoading(false);
    onStopReadAloud();
  };

  const loadSession = (session: ChatSession) => {
    setActiveSessionIdState(session.id);
    lsSetActiveSessionId(session.id);
    currentSessionRef.current = session;
    setInputPrompt('');
    setPendingAttachments([]);
    onStopReadAloud();
  };

  const deleteMessage = (msgId: string) => {
    if (!currentSessionRef.current) return;
    const nextMessages = messages.filter((m) => m.id !== msgId);
    const updatedSessions = sessions.map((s) =>
      s.id === currentSessionRef.current!.id ? { ...s, messages: nextMessages, updatedAt: Date.now() } : s
    );
    setSessionsState(updatedSessions);
    setSessions(updatedSessions);
    if (speakingMessageId === msgId) onStopReadAloud();
  };

  const removePendingAttachment = (id: string) => setPendingAttachments((prev) => prev.filter((a) => a.id !== id));

  /* ---------- Mini prompts ---------- */
  const handleInsertMiniPrompt = (snippet: string) => {
    setInputPrompt((prev) => { const trimmed = prev.trim(); return trimmed ? `${trimmed} ${snippet}` : snippet; });
    setTimeout(() => { if (textareaRef.current) { textareaRef.current.focus(); textareaRef.current.style.height = 'auto'; textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`; } }, 10);
  };

  /* ---------- Edit / resend ---------- */
  const handleStartEditMessage = (msg: ChatMessage) => {
    setEditingMessageId(msg.id);
    setEditText(msg.text);
  };

  const handleSaveAndResend = (msgId: string) => {
    const trimmed = editText.trim();
    if (!trimmed) return;
    if (abortControllerRef.current) { isUserAbortedRef.current = true; abortControllerRef.current.abort(); abortControllerRef.current = null; }
    setIsLoading(false);
    const msgIndex = messages.findIndex((m) => m.id === msgId);
    if (msgIndex === -1) return;
    const updatedUserMsg: ChatMessage = { ...messages[msgIndex], text: trimmed, timestamp: Date.now() };
    const newHistory = [...messages.slice(0, msgIndex), updatedUserMsg];
    const updatedSessions = sessions.map((s) => s.id === activeSessionId ? { ...s, messages: newHistory, updatedAt: Date.now() } : s);
    setSessionsState(updatedSessions);
    setSessions(updatedSessions);
    setEditingMessageId(null);
    setEditText('');
    setTimeout(() => sendMessage(trimmed, newHistory), 60);
  };

  /* ---------- Core: send + stream ---------- */
  const sendMessage = useCallback(async (textToSend?: string, currentHistory?: ChatMessage[]) => {
    const prompt = (textToSend || inputPrompt).trim();
    const attachmentsToSend = [...pendingAttachments];
    if (!prompt && attachmentsToSend.length === 0) return;

    const key = apiKeys[activeProvider];
    if (!key) {
      alert(`No API key set for ${activeProvider}. Please add it in Settings.`);
      return;
    }

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: prompt,
      timestamp: Date.now(),
      ...(attachmentsToSend.length > 0 ? { attachments: attachmentsToSend } : {}),
    };

    const baseHistory = currentHistory ? [...currentHistory] : [...messages, userMessage];
    if (!currentHistory) {
      const updatedSessions = sessions.map((s) => s.id === activeSessionId ? { ...s, messages: baseHistory, updatedAt: Date.now() } : s);
      setSessionsState(updatedSessions);
      setSessions(updatedSessions);
    }

    setInputPrompt('');
    setPendingAttachments([]);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    setIsLoading(true);
    setActiveStreamingText('');
    setActiveStreamingThought('');
    setIsThinkingActive(false);
    setFallbackNotice(null);

    const controller = new AbortController();
    abortControllerRef.current = controller;
    isUserAbortedRef.current = false;

    /* Apply history limit */
    const limit = settings.historyLimit || 10;
    const effectiveHistory = baseHistory.length > limit ? baseHistory.slice(-limit) : baseHistory;

    /* Build wire messages */
    const wireMessages = effectiveHistory.map((m) => ({
      role: m.role,
      text: m.text,
      ...(m.attachments ? { attachments: m.attachments } : {}),
    }));

    /* Resolve provider request */
    const cfg = getProviderConfig(activeProvider);
    const ctx = {
      signal: controller.signal,
      config: cfg || { name: activeProvider, baseUrl: '', apiKey: key, cascade: [], thinkingMode: 'default', maxTokens: 8192 },
      messages: wireMessages,
      settings: { stream: streamingEnabled, maxTokens: (cfg?.maxTokens ?? settings.maxTokens), thinkingMode: (cfg?.thinkingMode ?? settings.thinkingMode) },
      webSearch: webSearchEnabled,
      tavilyKey: settings.tavilyApiKey,
    };

    let resolvedModelName = '';
    let accumulatedText = '';
    let accumulatedThought = '';

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ctx),
        signal: controller.signal,
      });

      if (!res.ok || !res.body) {
        throw new Error('Streaming connection failed');
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let sseBuffer = '';

      while (true) {
        if (controller.signal.aborted) break;
        const { value, done } = await reader.read();
        if (done) break;
        sseBuffer += decoder.decode(value, { stream: true });
        const lines = sseBuffer.split('\n');
        sseBuffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed.startsWith(':')) continue;
          if (trimmed.startsWith('data: ')) {
            const jsonStr = trimmed.slice(6).trim();
            if (!jsonStr || jsonStr === '[DONE]') continue;
            let eventData: any = null;
            try { eventData = JSON.parse(jsonStr); } catch { continue; }
            if (eventData.type === 'error') { throw new Error(eventData.error || 'Stream error'); }
            else if (eventData.type === 'model_init') { resolvedModelName = eventData.model; setActiveModelUsed(eventData.model); }
            else if (eventData.type === 'thinking') { setIsThinkingActive(true); }
            else if (eventData.type === 'thought') { setIsThinkingActive(true); accumulatedThought += eventData.text; setActiveStreamingThought(accumulatedThought); }
            else if (eventData.type === 'fallback_notice') {
              accumulatedText = ''; setActiveStreamingText(''); accumulatedThought = ''; setActiveStreamingThought('');
              setFallbackNotice(`Switched to ${eventData.nextModel}. Reason: ${eventData.reason || ''}`);
              resolvedModelName = eventData.nextModel;
              setActiveModelUsed(eventData.nextModel);
            } else if (eventData.type === 'chunk') {
              setIsThinkingActive(false);
              accumulatedText += eventData.text;
              setActiveStreamingText(accumulatedText);
            } else if (eventData.type === 'done') {
              if (eventData.modelUsed) { resolvedModelName = eventData.modelUsed; setActiveModelUsed(eventData.modelUsed); }
            }
          }
        }
      }

      if (!accumulatedText.trim() && accumulatedThought.trim()) {
        accumulatedText = accumulatedThought;
      }

      if (accumulatedText.trim() || accumulatedThought.trim()) {
        const aiMessage: ChatMessage = {
          id: `ai-${Date.now()}`,
          role: 'model',
          text: accumulatedText,
          ...(accumulatedThought ? { thought: accumulatedThought } : {}),
          timestamp: Date.now(),
          ...(resolvedModelName ? { modelUsed: resolvedModelName } : {}),
        };
        const finalHistory = [...baseHistory, aiMessage];
        const updatedSessions = sessions.map((s) => s.id === activeSessionId ? { ...s, messages: finalHistory, updatedAt: Date.now() } : s);
        setSessionsState(updatedSessions);
        setSessions(updatedSessions);
      }

    } catch (err: any) {
      if (err?.name === 'AbortError' || isUserAbortedRef.current) {
        const trimmedSoFar = accumulatedText.trim();
        const aiMessage: ChatMessage = {
          id: `ai-${Date.now()}`,
          role: 'model',
          text: trimmedSoFar ? `${trimmedSoFar}\n\n⏹️ *(Answer stopped)*` : '⏹️ *(Answer stopped)*',
          ...(accumulatedThought ? { thought: accumulatedThought } : {}),
          timestamp: Date.now(),
          ...(resolvedModelName ? { modelUsed: resolvedModelName } : {}),
        };
        const finalHistory = [...baseHistory, aiMessage];
        const updatedSessions = sessions.map((s) => s.id === activeSessionId ? { ...s, messages: finalHistory, updatedAt: Date.now() } : s);
        setSessionsState(updatedSessions);
        setSessions(updatedSessions);
        return;
      }
      console.warn('Streaming error:', err);
      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        text: `⚠️ Connection interrupted: ${err.message || 'Please retry'}.`,
        timestamp: Date.now(),
        modelUsed: 'Offline Recovery',
      };
      const updatedSessions = sessions.map((s) => s.id === activeSessionId ? { ...s, messages: [...s.messages, errorMessage], updatedAt: Date.now() } : s);
      setSessionsState(updatedSessions);
      setSessions(updatedSessions);
    } finally {
      setIsLoading(false);
      setActiveStreamingText('');
      setActiveStreamingThought('');
      setIsThinkingActive(false);
      setFallbackNotice(null);
      abortControllerRef.current = null;
      isUserAbortedRef.current = false;
    }
  }, [inputPrompt, pendingAttachments, activeProvider, apiKeys, settings, streamingEnabled, webSearchEnabled, messages, sessions, activeSessionId]);

  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      isUserAbortedRef.current = true;
      abortControllerRef.current.abort();
    }
    onStopReadAloud();
  };

  const handleCopyMarkdown = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const handleCopyText = (text: string) => {
    const plain = text.replace(/\[(\d+)\]/g, '').replace(/\*\*/g, '').replace(/`/g, '');
    navigator.clipboard.writeText(plain);
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, []);

  return (
    <div className="flex flex-col h-screen w-screen bg-black text-zinc-100 overflow-hidden font-sans">
      {/* Header */}
      <header className="shrink-0 h-14 border-b border-zinc-800 bg-[#09090b] px-4 sm:px-6 flex items-center justify-between gap-3 z-30">
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2 cursor-pointer group">
            <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-700 flex items-center justify-center font-black text-sm text-cyan-400">⚡</div>
            <h1 className="font-bold text-zinc-100 text-sm sm:text-base tracking-tight">Universal AI</h1>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button onClick={createNewSession} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 text-xs font-medium transition-colors shrink-0">
            <span className="w-3.5 h-3.5">💬</span> <span>New Chat</span>
          </button>
          <button onClick={() => setIsHistoryOpen(true)} className="px-2 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors shrink-0" title="Chat history">
            <span className="w-4 h-4 text-zinc-400">🕒</span>
          </button>
          <button onClick={() => setIsSystemPromptOpen(true)} className="px-2 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-emerald-400 hover:text-emerald-300 transition-colors shrink-0" title="System prompt">
            <span className="w-4 h-4 text-emerald-400">📝</span>
          </button>
          <button onClick={() => setIsSettingsOpen(true)} className="px-2 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors shrink-0" title="Settings">
            <span className="w-4 h-4 text-zinc-400">⚙️</span>
          </button>
        </div>
      </header>

      {/* Provider switcher */}
      <div className="shrink-0 px-4 sm:px-6 py-2 bg-black border-b border-zinc-800 overflow-x-auto">
        <ProviderSwitcher activeProvider={activeProvider} setActiveProvider={setActiveProvider} />
      </div>

      {/* Chat canvas */}
      <ChatCanvas
        messages={messages}
        activeModelUsed={activeModelUsed}
        isLoading={isLoading}
        activeStreamingText={activeStreamingText}
        activeStreamingThought={activeStreamingThought}
        isThinkingActive={isThinkingActive}
        fallbackNotice={fallbackNotice}
        speakingMessageId={speakingMessageId}
        isPaused={isPaused}
        onCopyMarkdown={handleCopyMarkdown}
        onCopyText={handleCopyText}
        onReadAloud={handleReadAloud}
        onPauseResume={handlePauseResume}
        onStopReadAloud={onStopReadAloud}
        onEditQuery={handleStartEditMessage}
        onDeleteMessage={deleteMessage}
        editingMessageId={editingMessageId}
        setEditingMessageId={setEditingMessageId}
        editText={editText}
        setEditText={setEditText}
        onSaveResend={handleSaveAndResend}
      />

      {/* Composer */}
      <Composer
        inputPrompt={inputPrompt}
        setInputPrompt={setInputPrompt}
        pendingAttachments={pendingAttachments}
        setPendingAttachments={setPendingAttachments}
        removePendingAttachment={removePendingAttachment}
        isLoading={isLoading}
        onStopStreaming={handleStopStreaming}
        onSend={() => sendMessage()}
        onAttach={() => fileInputRef.current?.click()}
        onInsertMiniPrompt={handleInsertMiniPrompt}
        onToggleWebSearch={() => setSettingsState((s) => ({ ...s, webSearch: !s.webSearch }))}
        webSearchEnabled={webSearchEnabled}
        onToggleStreaming={() => setSettingsState((s) => ({ ...s, streaming: !s.streaming }))}
        streamingEnabled={streamingEnabled}
        fileInputRef={fileInputRef}
        textareaRef={textareaRef}
        disabled={!apiKeys[activeProvider]}
      />

      {/* Modals */}
      <CascadeEditor isOpen={isCascadeOpen} onClose={() => setIsCascadeOpen(false)} />
      <ChatHistoryDrawer isOpen={isHistoryOpen} onClose={() => setIsHistoryOpen(false)} onLoadSession={loadSession} onNewSession={createNewSession} />
      <SystemPromptEditor isOpen={isSystemPromptOpen} onClose={() => setIsSystemPromptOpen(false)} currentPrompt={settings.systemPrompt} onUpdate={(p) => setSettingsState((s) => ({ ...s, systemPrompt: p }))} />
      <TavilySettings isOpen={isTavilyOpen} onClose={() => setIsTavilyOpen(false)} settings={settings} onUpdate={(s) => setSettingsState(s)} />
      <SettingsPanel isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} settings={settings} onUpdateSettings={(s) => setSettingsState(s)} />
      <MiniPromptDrawer isOpen={isMiniPromptOpen} onClose={() => setIsMiniPromptOpen(false)} onInsertPrompt={handleInsertMiniPrompt} />
    </div>
  );
}
