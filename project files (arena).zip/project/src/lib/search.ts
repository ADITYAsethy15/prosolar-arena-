export const TAVILY_URL = 'https://api.tavily.com/search';

export function queryText(raw: string): string {
  return Array.from(raw.trim().replace(/\s+/g, ' ')).slice(0, 400).join('');
}

export function buildTavilyBody(
  query: string,
  depth: 'basic' | 'advanced' | 'fast' | 'ultra-fast',
  count: number,
  allowSites: string[],
  blockSites: string[],
): any {
  const q = queryText(query);
  const body: any = {
    query: q,
    search_depth: depth === 'advanced' ? 'advanced' : 'basic',
    max_results: Math.min(10, Math.max(1, Math.round(count) || 5)),
    safe_search: true,
    include_answer: false,
    include_images: false,
    include_raw_content: false,
    auto_parameters: false,
  };
  if (allowSites.length) body.include_domains = allowSites;
  if (blockSites.length) body.exclude_domains = blockSites;
  return body;
}

export async function fetchTavily(
  apiKey: string,
  query: string,
  depth: 'basic' | 'advanced' | 'fast' | 'ultra-fast',
  count: number,
  allowSites: string[],
  blockSites: string[],
  signal: AbortSignal,
): Promise<{ results: any[]; answer?: string }> {
  if (!apiKey.trim()) throw new Error('Tavily API key not configured in Settings.');
  const body = buildTavilyBody(query, depth, count, allowSites, blockSites);

  const deadline = AbortSignal.timeout(25_000);
  const res = await fetch(TAVILY_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify(body),
    signal: AbortSignal.any([signal, deadline]),
    redirect: 'error',
  });

  if (!res.ok) {
    const status = res.status;
    let msg = 'Search failed.';
    if (status === 401 || status === 403) msg = 'Check the Tavily API key in Settings.';
    else if (status === 429) msg = 'Tavily rate limit reached. Wait before trying again.';
    else if ([402, 432, 433, 434].includes(status)) msg = 'Check usage and credits on your Tavily account.';
    else if (status === 504) msg = 'Tavily timed out.';
    throw new Error(`Tavily HTTP ${status} · ${msg}`);
  }

  const json = await res.json();
  return {
    results: (json.results || []).map((r: any, i: number) => ({
      ...r,
      sourceNumber: i + 1,
      url: r.url,
      title: r.title,
      content: r.content,
    })),
    answer: json.answer,
  };
}
