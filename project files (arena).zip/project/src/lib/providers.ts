import type { ProviderId, ProviderConfig, ThinkingMode, WireMessage } from '@/types';
import {
  reasonFields,
  providerIdFromBase,
} from './reasoning';

/* ---------- Model catalog discovery (Universa's getModels pattern) ---------- */

export async function testConnection(
  baseUrl: string,
  apiKey: string,
  signal?: AbortSignal,
): Promise<{ listed: boolean; ids: string[] }> {
  const base = normaliseBase(baseUrl);
  const provider = providerIdFromBase(base);

  // Gemini: use native SDK models.list via REST
  if (provider === 'google') {
    try {
      const url = `${base}/models`;
      const res = await fetch(url, {
        headers: { 'x-goog-api-key': apiKey },
        signal,
        redirect: 'error',
      });
      if (!res.ok) return { listed: false, ids: [] };
      const json = await res.json();
      const ids: string[] = [];
      for (const m of (json as any).models || []) {
        const id = m.name?.replace(/^models\//, '') || m.id;
        if (id && !id.includes('embed') && !/tts|image|audio|live|robotics/i.test(id)) {
          ids.push(id);
        }
      }
      return { listed: true, ids: [...new Set(ids)].sort() };
    } catch {
      return { listed: false, ids: [] };
    }
  }

  // OpenAI-compatible: GET /models
  try {
    const res = await fetch(`${base}/models`, {
      headers: { Authorization: `Bearer ${apiKey}`, Accept: 'application/json' },
      signal,
      redirect: 'error',
    });
    if (!res.ok) return { listed: false, ids: [] };
    const json = await res.json();
    const data = json.data || [];
    const ids: string[] = [];
    for (const row of data) {
      const id = row.id;
      if (typeof id === 'string' && id) ids.push(id);
    }
    return { listed: true, ids: [...new Set(ids)].sort() };
  } catch {
    return { listed: false, ids: [] };
  }
}

function normaliseBase(raw: string): string {
  try {
    const url = new URL(raw.trim());
    const path = url.pathname.replace(/\/+$/, '').replace(/(chat\/completions|models)$/, '');
    return `${url.origin}${path}`;
  } catch {
    return raw.trim();
  }
}

/* ---------- Payload builders per provider ---------- */

export function buildChatPayload(
  _providerId: ProviderId,
  config: ProviderConfig,
  messages: WireMessage[],
  settings: { stream: boolean; maxTokens: number; thinkingMode: ThinkingMode },
): any {
  const base = normaliseBase(config.baseUrl || '');
  const provider = providerIdFromBase(base);

  const systemPrompt = config.name ? `System: ${config.name}` : '';

  // Build OpenAI-compatible messages array
  const oaiMessages: any[] = [];
  if (systemPrompt && systemProviderNeedsSystemPrompt(provider)) {
    oaiMessages.push({ role: 'system', content: systemPrompt });
  }

  for (const m of messages) {
    const content: any = m.text;
    oaiMessages.push({
      role: m.role === 'model' ? 'assistant' : 'user',
      content,
      ...(m.attachments?.length ? { attachments: m.attachments } : {}),
    });
  }

  const thinkingMode = config.thinkingMode || settings.thinkingMode;
  const rf = reasonFields(base, messages[messages.length - 1]?.text ?? '', thinkingMode);

  const maxTokens = config.maxTokens || settings.maxTokens;

  // Gemini native SDK path
  if (provider === 'google') {
    return {
      provider: 'gemini-native',
      model: config.cascade[0] || 'gemini-1.5-flash-latest',
      messages: oaiMessages,
      stream: settings.stream,
      maxOutputTokens: maxTokens,
      thinkingConfig: rf.thinking_config ?? undefined,
      streamTimeout: 240_000,
    };
  }

  // OpenAI-compatible path (Groq, OpenRouter, NVIDIA, Z.AI, Custom)
  const payload: any = {
    model: config.cascade[0] || 'gpt-3.5-turbo',
    messages: oaiMessages,
    stream: settings.stream,
    ...(provider === 'groq' ? { max_completion_tokens: maxTokens } : { max_tokens: maxTokens }),
    ...rf,
  };

  if (provider === 'zai' && rf.temperature === undefined) {
    payload.temperature = 0.7;
  }

  return { provider: 'openai-compatible', base, apiKey: config.apiKey, payload };
}

function systemProviderNeedsSystemPrompt(provider: string | undefined): boolean {
  return provider !== 'google'; // Gemini SDK uses systemInstruction separately
}

/* ---------- Per-provider stream handlers (used by serverless API) ---------- */

export interface StreamHandlerContext {
  req: Request;
  signal: AbortSignal;
  config: ProviderConfig;
  messages: WireMessage[];
  settings: { stream: boolean; maxTokens: number; thinkingMode: ThinkingMode };
}

/**
 * Determines which provider adapter to use and builds the initial request.
 * The actual streaming is done in api/chat.ts using fetch with the signal.
 */
export function resolveProviderRequest(ctx: StreamHandlerContext): {
  provider: 'gemini-native' | 'openai-compatible';
  url: string;
  headers: Record<string, string>;
  body: any;
  signal: AbortSignal;
} {
  const { config, messages, settings } = ctx;
  const base = normaliseBase(config.baseUrl || '');
  const provider = providerIdFromBase(base);

  if (provider === 'google') {
    const model = config.cascade[0] || 'gemini-1.5-flash-latest';
    return {
      provider: 'gemini-native',
      url: `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?key=${config.apiKey}`,
      headers: { 'Content-Type': 'application/json' },
      body: {
        contents: messages.map((m) => ({
          role: m.role === 'model' ? 'model' : 'user',
          parts: [{ text: m.text }],
        })),
        generationConfig: {
          maxOutputTokens: config.maxTokens || settings.maxTokens,
          temperature: 0.7,
        },
      },
      signal: ctx.signal,
    };
  }

  const model = config.cascade[0] || 'gpt-3.5-turbo';
  const payload = {
    model,
    messages: messages.map((m) => ({
      role: m.role === 'model' ? 'assistant' : 'user',
      content: m.text,
    })),
    stream: true,
    ...(provider === 'groq' ? { max_completion_tokens: config.maxTokens || settings.maxTokens } : { max_tokens: config.maxTokens || settings.maxTokens }),
    temperature: 0.7,
  };

  return {
    provider: 'openai-compatible',
    url: `${base}/chat/completions`,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${config.apiKey}`,
    },
    body: payload,
    signal: ctx.signal,
  };
}

// PROVIDER_DISPLAY is defined in src/types.ts
