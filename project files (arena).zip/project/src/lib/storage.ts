import {
  AppSettings,
  ChatSession,
  LS_KEYS,
  ProviderConfig,
} from '@/types';

const API_KEYS_DEFAULT: Record<string, string> = {};
const CUSTOM_PROVIDERS_DEFAULT: Record<string, { name: string; endpoint: string; apiKey: string }> = {};
const PROVIDER_CONFIGS_DEFAULT: Record<string, ProviderConfig> = {};

export function lsGet<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function lsSet<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    // QuotaExceededError: try to compact sessions and retry once
    if (e instanceof DOMException && e.name === 'QuotaExceededError') {
      try {
        const sessions = lsGet<ChatSession[]>('ai_sessions', []);
        const compacted = sessions.map((s) => ({
          ...s,
          messages: s.messages.map((m) => ({
            ...m,
            attachments: m.attachments?.map(({ id, name, mimeType, size }) => ({
              id, name, mimeType, size,
            })) || [],
          })),
        }));
        localStorage.setItem('ai_sessions', JSON.stringify(compacted));
        localStorage.setItem(key, JSON.stringify(value));
      } catch {
        /* best effort */
      }
    }
    console.warn('localStorage write failed for key:', key);
  }
}

export function lsRemove(key: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

/* ---------- API Keys ---------- */
export function getApiKeys(): Record<string, string> {
  return lsGet<Record<string, string>>(LS_KEYS.apiKeys, API_KEYS_DEFAULT);
}
export function setApiKeys(keys: Record<string, string>): void {
  lsSet(LS_KEYS.apiKeys, keys);
}
export function setApiKey(providerId: string, key: string): void {
  const keys = getApiKeys();
  keys[providerId] = key;
  setApiKeys(keys);
}

/* ---------- Custom Providers ---------- */
export function getCustomProviders(): Record<string, { name: string; endpoint: string; apiKey: string }> {
  return lsGet<Record<string, { name: string; endpoint: string; apiKey: string }>>(LS_KEYS.customProviders, CUSTOM_PROVIDERS_DEFAULT);
}
export function setCustomProvider(baseUrl: string, cfg: { name: string; endpoint: string; apiKey: string }): void {
  const map = getCustomProviders();
  map[baseUrl] = cfg;
  lsSet(LS_KEYS.customProviders, map);
}
export function removeCustomProvider(baseUrl: string): void {
  const map = getCustomProviders();
  delete map[baseUrl];
  lsSet(LS_KEYS.customProviders, map);
}

/* ---------- Provider Configs (cascades + thinking mode) ---------- */
export function getProviderConfigs(): Record<string, ProviderConfig> {
  return lsGet<Record<string, ProviderConfig>>(LS_KEYS.providerConfigs, PROVIDER_CONFIGS_DEFAULT);
}
export function setProviderConfigs(map: Record<string, ProviderConfig>): void {
  lsSet(LS_KEYS.providerConfigs, map);
}
export function getProviderConfig(providerId: string): ProviderConfig | null {
  const map = getProviderConfigs();
  return map[providerId] ?? null;
}
export function setProviderConfig(providerId: string, cfg: ProviderConfig): void {
  const map = getProviderConfigs();
  map[providerId] = cfg;
  lsSet(LS_KEYS.providerConfigs, map);
}

/* ---------- Settings ---------- */
export const DEFAULT_SETTINGS: AppSettings = {
  historyLimit: 10,
  maxTokens: 8192,
  streaming: true,
  thinkingMode: 'default',
  webSearch: false,
  tavilyApiKey: '',
  tavilyDepth: 'basic',
  tavilyResults: 5,
  tavilyAllowSites: '',
  tavilyBlockSites: '',
  themeAccent: '#22d3ee',
  systemPrompt: '',
};

export function getSettings(): AppSettings {
  return lsGet<AppSettings>(LS_KEYS.settings, DEFAULT_SETTINGS);
}
export function setSettings(settings: AppSettings): void {
  lsSet(LS_KEYS.settings, settings);
}

/* ---------- Sessions ---------- */
export function getSessions(): ChatSession[] {
  return lsGet<ChatSession[]>(LS_KEYS.sessions, []);
}
export function setSessions(sessions: ChatSession[]): void {
  // keep only last 10
  const trimmed = sessions.slice(0, 10);
  lsSet(LS_KEYS.sessions, trimmed);
}
export function getActiveSessionId(): string | null {
  return lsGet<string | null>(LS_KEYS.activeSessionId, null);
}
export function setActiveSessionId(id: string | null): void {
  if (id === null) lsRemove(LS_KEYS.activeSessionId);
  else lsSet(LS_KEYS.activeSessionId, id);
}
export const lsSetActiveSessionId = setActiveSessionId;

/* ---------- Migration: ensure empty cascades on fresh install ---------- */
export function ensureProviderConfigs(): void {
  const existing = getProviderConfigs();
  let changed = false;
  for (const pid of ['gemini', 'groq', 'openrouter', 'nvidia', 'zai', 'custom-1', 'custom-2'] as const) {
    if (!existing[pid]) {
      existing[pid] = {
        name: pid,
        baseUrl: '',
        apiKey: '',
        cascade: [],
        thinkingMode: 'default',
        maxTokens: 8192,
      };
      changed = true;
    }
  }
  if (changed) setProviderConfigs(existing);
}
