import type { ThinkingMode } from '@/types';

export type Mode = ThinkingMode;

type Style = 'effort' | 'groq-oss' | 'groq-qwen' | 'nim-switch';

type Rule = { style: Style; modes: readonly Mode[] };

const levels: Mode[] = ['low', 'medium', 'high'];

function effort(modes: readonly Mode[] = levels, style: Style = 'effort'): Rule {
  return { style, modes };
}

// Per-provider, per-model thinking capability rules.
// Grounded in provider docs: Google AI Studio, Groq, OpenRouter, NVIDIA NIM, Z.AI.
const google: Record<string, Rule> = {};
for (const id of [
  'gemini-2.5-pro',
  'gemini-3.1-pro-preview',
  'gemini-3.8-flash',
  'gemini-4-carbon',
  'gemini-4-argon',
])
  google[id] = effort();
for (const id of ['gemini-2.5-flash', 'gemini-2.5-flash-lite'])
  google[id] = effort(['none', ...levels]);
for (const id of [
  'gemini-3-flash-preview',
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.6-flash',
])
  google[id] = effort(['minimal', ...levels]);
google['gemini-3-pro-preview'] = effort(['low', 'high']);
google['gemini-4-hydrogen'] = effort([...levels, 'xhigh']);

const groq: Record<string, Rule> = {
  'openai/gpt-oss-20b': effort(levels, 'groq-oss'),
  'openai/gpt-oss-120b': effort(levels, 'groq-oss'),
  'qwen/qwen3.8-27b': effort(['none', ...levels], 'groq-qwen'),
  'qwen/qwen3-32b': effort(['none', 'on'], 'groq-qwen'),
  'meta-models/muse-spark-open': effort([...levels, 'xhigh']),
};

const nvidia: Record<string, Rule> = {
  'openai/gpt-oss-20b': effort(),
  'openai/gpt-oss-120b': effort(),
  'mistralai/mistral-large-4-1t-a52b': effort(),
  'z-ai/glm-5.3-flash': effort(['low', 'high', 'max']),
};
for (const id of [
  'google/gemma-4-31b-it',
  'google/gemma-4-26b-a4b-it',
  'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning',
  'nvidia/nemotron-3-super-120b-a12b',
  'nvidia/nemotron-3-ultra-550b-a55b',
  'nvidia/nemotron-3.5-lightning-30b-a3b',
])
  nvidia[id] = effort(['none', 'on'], 'nim-switch');

const providerTables: Record<string, Record<string, Rule>> = {
  google,
  groq,
  nvidia,
};

export function providerIdFromBase(baseUrl: string): string | undefined {
  const b = baseUrl.toLowerCase();
  if (b.includes('generativelanguage.googleapis.com')) return 'google';
  if (b.includes('api.groq.com')) return 'groq';
  if (b.includes('openrouter.ai')) return 'openrouter';
  if (b.includes('integrate.api.nvidia.com')) return 'nvidia';
  if (b.includes('api.z.ai')) return 'zai';
  return undefined;
}

export function reasonRule(baseUrl: string, model: string): Rule | undefined {
  const table = providerTables[providerIdFromBase(baseUrl) ?? ''];
  if (!table) return undefined;
  const name = model.trim().toLowerCase().replace(/^models\//, '');
  return table[name] ?? undefined;
}

export function modeFor(baseUrl: string, model: string, choices?: Record<string, Mode>): Mode {
  const key = JSON.stringify([providerIdFromBase(baseUrl) ?? '', model.trim()]);
  const value = choices?.[key];
  const rule = reasonRule(baseUrl, model);
  return value && rule?.modes.includes(value) ? value : 'default';
}

type ReasonFields = {
  reasoning_effort?: string;
  include_reasoning?: boolean;
  reasoning_format?: 'hidden';
  chat_template_kwargs?: { enable_thinking: boolean };
  thinking?: { type: 'enabled' | 'disabled' };
  thinking_config?: { thinking_level: string; include_thoughts: boolean };
  max_tokens?: number;
  max_completion_tokens?: number;
  temperature?: number;
};

export function reasonFields(baseUrl: string, model: string, mode: Mode): ReasonFields {
  if (mode === 'default') return {};
  const rule = reasonRule(baseUrl, model);
  if (!rule || !rule.modes.includes(mode)) {
    throw new Error('Unsupported reasoning setting for this provider and model. Select Default.');
  }

  const provider = providerIdFromBase(baseUrl);

  // Z.AI special: thinking must be enabled, never disabled
  if (provider === 'zai') {
    return {
      thinking: { type: 'enabled' },
      reasoning_effort: mode === 'none' ? 'low' : mode === 'minimal' ? 'low' : mode === 'medium' ? 'high' : mode === 'xhigh' ? 'max' : mode === 'max' ? 'max' : mode,
    };
  }

  if (rule.style === 'nim-switch') {
    return { chat_template_kwargs: { enable_thinking: mode === 'on' } };
  }

  const effortValue = mode === 'on' ? 'default' : mode;

  const fields: ReasonFields = {
    reasoning_effort: effortValue,
  };

  if (rule.style === 'groq-oss') {
    fields.include_reasoning = false;
  } else if (rule.style === 'groq-qwen') {
    fields.reasoning_format = 'hidden';
  }

  return fields;
}

/**
 * Self-healing retry parameter repair.
 * Returns a list of alternative payloads to try, in order, when a provider
 * rejects thinking/reasoning/sampling parameters with HTTP 400/422.
 */
export function repairParams(
  _baseUrl: string,
  _model: string,
  _mode: Mode,
  originalFields: ReasonFields,
): ReasonFields[] {
  const provider = providerIdFromBase(_baseUrl);
  const repairs: ReasonFields[] = [];

  if (provider === 'google') {
    repairs.push({});
    repairs.push({ thinking_config: { thinking_level: 'low', include_thoughts: true } });
  } else if (provider === 'nvidia') {
    if (originalFields.reasoning_effort) {
      repairs.push({ chat_template_kwargs: { enable_thinking: true } });
    } else if (originalFields.chat_template_kwargs) {
      repairs.push({ reasoning_effort: 'low' });
    }
    repairs.push({});
  } else if (provider === 'zai') {
    repairs.push({ thinking: { type: 'enabled' }, reasoning_effort: 'low' });
    repairs.push({});
  } else if (provider === 'groq') {
    repairs.push({ reasoning_effort: 'low' });
    repairs.push({});
  } else {
    repairs.push({});
  }

  repairs.push({});

  const seen = new Set<string>();
  const unique: ReasonFields[] = [];
  for (const r of repairs) {
    const sig = JSON.stringify(r);
    if (!seen.has(sig)) {
      seen.add(sig);
      unique.push(r);
    }
  }
  return unique;
}

export function isReasoningParamError(message: string): boolean {
  const lower = message.toLowerCase();
  const params = [
    'thinking', 'thinkingconfig', 'thinking_level', 'thinking_budget',
    'reasoning', 'reasoning_effort', 'reasoning_format', 'include_reasoning',
    'chat_template_kwargs', 'temperature', 'top_p', 'top_k',
    'max_tokens', 'max_completion_tokens',
  ];
  return params.some((p) => lower.includes(p));
}
